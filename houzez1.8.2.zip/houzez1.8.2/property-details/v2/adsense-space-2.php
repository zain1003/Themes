<div class="adv-wrapper property-v2">
	<?php echo houzez_option('adsense_space_2');?>
</div>