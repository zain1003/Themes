<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

?>
<div class="header-search-box">
    <a href="#header-search" title="<?php esc_attr_e( 'Search', 'digeco');?>">
        <i class="flaticon-search"></i>
    </a>
</div>

