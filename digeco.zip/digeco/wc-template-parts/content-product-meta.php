<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

global $product;
do_action( 'woocommerce_product_meta_start' );

do_action( 'woocommerce_product_meta_end' ); 

